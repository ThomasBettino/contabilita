'use strict';

/* ---------- Costanti ---------- */
const MESI = ['Gennaio', 'Febbraio', 'Marzo', 'Aprile', 'Maggio', 'Giugno', 'Luglio', 'Agosto', 'Settembre', 'Ottobre', 'Novembre', 'Dicembre'];
const MESI_INI = ['G', 'F', 'M', 'A', 'M', 'G', 'L', 'A', 'S', 'O', 'N', 'D'];
const STATI = ['inviata', 'fatturata', 'incassata'];
const STATO_LABEL = { inviata: 'Mandata a Giulia', fatturata: 'Fatturata · attesa bonifico', incassata: 'Bonifico arrivato', scaduta: 'Scaduta' };
const GENERATORE = 'https://claude.ai/artifact/Wp6LGizc6G93siNaxbsJFV';
const SOGLIA_BOLLO = 77.47;

const I = {
  home: '<path d="M3 10l9-7 9 7v10a1 1 0 0 1-1 1h-5v-6H9v6H4a1 1 0 0 1-1-1z"/>',
  doc: '<path d="M14 3H6a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z"/><path d="M14 3v6h6"/><path d="M8 13h8M8 17h5"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  pct: '<path d="M19 5L5 19"/><circle cx="6.5" cy="6.5" r="2.5"/><circle cx="17.5" cy="17.5" r="2.5"/>',
  bell: '<path d="M6 8a6 6 0 1 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/><path d="M10.3 21a1.94 1.94 0 0 0 3.4 0"/>',
  left: '<path d="M15 6l-6 6 6 6"/>',
  right: '<path d="M9 6l6 6-6 6"/>',
  clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
  mail: '<path d="M3 6h18v12H3z"/><path d="M3 6l9 7 9-7"/>',
  folder: '<path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>',
  check: '<path d="M5 12l5 5 9-10"/>',
  search: '<circle cx="11" cy="11" r="7"/><path d="M20 20l-3.5-3.5"/>',
  down: '<path d="M12 3v12M7 10l5 5 5-5M5 21h14"/>',
  x: '<path d="M6 6l12 12M18 6L6 18"/>',
  alert: '<path d="M12 9v4M12 17h.01"/><path d="M10.3 3.9L1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0z"/>',
  sync: '<path d="M21 12a9 9 0 0 1-15 6.7L3 16"/><path d="M3 12a9 9 0 0 1 15-6.7L21 8"/><path d="M21 3v5h-5M3 21v-5h5"/>',
  out: '<path d="M14 4h6v6"/><path d="M20 4l-9 9"/><path d="M18 14v5a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1h5"/>'
};
const svg = (k, s = 20, w = 2) => `<svg width="${s}" height="${s}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="${w}" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${I[k]}</svg>`;

/* ---------- Utilità ---------- */
const pad = (n) => String(n).padStart(2, '0');
const isoOggi = () => { const d = new Date(); return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`; };
const meseDi = (iso) => (iso || '').slice(0, 7);
const eur = (n) => {
  const v = (Math.round((Number(n) || 0) * 100) / 100).toFixed(2).split('.');
  return '€ ' + v[0].replace(/\B(?=(\d{3})+(?!\d))/g, '.') + ',' + v[1];
};
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const num = (s) => { if (typeof s === 'number') return s; const v = parseFloat(String(s || '').replace(/[^\d,.-]/g, '').replace(/\.(?=\d{3}(\D|$))/g, '').replace(',', '.')); return isNaN(v) ? 0 : v; };
const dataBreve = (iso) => { if (!iso) return '—'; const [, m, d] = iso.split('-'); return `${Number(d)} ${MESI[Number(m) - 1].slice(0, 3).toLowerCase()}`; };
const giorniDa = (iso) => Math.floor((Date.now() - new Date(iso + 'T12:00:00').getTime()) / 86400000);
const uid = () => (crypto.randomUUID ? crypto.randomUUID() : Date.now().toString(36) + Math.random().toString(36).slice(2));

const store = {
  get(k, d) { try { const v = localStorage.getItem(k); return v ? JSON.parse(v) : d; } catch (e) { return d; } },
  set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { /* memoria piena o bloccata */ } }
};

/* ---------- Stato ---------- */
const S = {
  cfg: Object.assign({ ena: 8.5, tasse: 30, giorni: 30, url: '', token: '' }, store.get('cs-cfg', {})),
  fatture: store.get('cs-fatture', []),
  acc: store.get('cs-acc', {}),
  coda: store.get('cs-coda', []),
  view: 'home', id: null,
  mese: isoOggi().slice(0, 7),
  anno: new Date().getFullYear(),
  filtro: 'tutte', cerca: '', aperto: null,
  bozza: null, sync: '', occupato: false
};

function salva() {
  store.set('cs-cfg', S.cfg);
  store.set('cs-fatture', S.fatture);
  store.set('cs-acc', S.acc);
  store.set('cs-coda', S.coda);
}

/* ---------- Calcoli ----------
   Come nel generatore di fatture: imponibile + bollo (2 € sopra 77,47 €) − Enasarco 8,5% = bonifico.
   Le tasse si accantonano sul netto = imponibile − Enasarco. */
function calc(f) {
  const lordo = num(f.lordo);
  const bollo = f.bollo !== undefined && f.bollo !== '' ? num(f.bollo) : (lordo > SOGLIA_BOLLO ? 2 : 0);
  const ena = Math.round(lordo * S.cfg.ena) / 100;
  const netto = lordo - ena;
  const tasse = Math.round(netto * S.cfg.tasse) / 100;
  return { lordo, bollo, ena, netto, tasse, bonifico: lordo + bollo - ena };
}
const scaduta = (f) => f.stato !== 'incassata' && !!f.data && giorniDa(f.data) > S.cfg.giorni;
const statoVis = (f) => (scaduta(f) ? 'scaduta' : f.stato);
function etichetta(f) {
  const sv = statoVis(f);
  if (sv === 'scaduta') return ['scaduta', `Scaduta · ${giorniDa(f.data) - S.cfg.giorni} gg`];
  return [sv, STATO_LABEL[sv]];
}
const somma = (lista, k) => lista.reduce((s, f) => s + calc(f)[k], 0);
const delMese = (m) => S.fatture.filter((f) => meseDi(f.data) === m);
const ordinate = (lista) => lista.slice().sort((a, b) => (b.data || '').localeCompare(a.data || ''));
function meseShift(m, d) { let [y, mm] = m.split('-').map(Number); mm += d; while (mm < 1) { mm += 12; y--; } while (mm > 12) { mm -= 12; y++; } return `${y}-${pad(mm)}`; }
const nomeMese = (m) => { const [y, mm] = m.split('-'); return `${MESI[Number(mm) - 1]} ${y}`; };

/* ---------- Sincronizzazione con lo script Google ---------- */
async function api(body) {
  const r = await fetch(S.cfg.url, {
    method: 'POST',
    headers: { 'Content-Type': 'text/plain;charset=utf-8' },
    body: JSON.stringify(Object.assign({}, body, { token: S.cfg.token }))
  });
  const j = await r.json();
  if (!j.ok) throw new Error(j.error || 'Errore dello script');
  return j;
}
async function sincronizza(silenzioso) {
  if (!S.cfg.url || S.occupato) return;
  S.occupato = true; S.sync = 'Sincronizzo…'; if (!silenzioso) render();
  try {
    while (S.coda.length) { await api(S.coda[0]); S.coda.shift(); salva(); }
    const j = await api({ action: 'list' });
    S.fatture = j.fatture || [];
    S.acc = j.accantonamenti || {};
    salva();
    const d = new Date();
    S.sync = `Aggiornato alle ${pad(d.getHours())}:${pad(d.getMinutes())}`;
  } catch (e) {
    S.sync = 'Non collegato · ' + e.message;
  }
  S.occupato = false;
  render();
}
function invia(op) {
  if (!S.cfg.url) return;
  S.coda.push(op); salva(); sincronizza(true);
}

/* ---------- Modifiche ai dati ---------- */
function aggiorna(id, campi) {
  const f = S.fatture.find((x) => x.id === id); if (!f) return;
  Object.assign(f, campi); salva();
  invia({ action: 'update', id, fields: campi });
}
function aggiungi(f) {
  f.id = uid(); f.creato = new Date().toISOString();
  S.fatture.push(f); salva();
  invia({ action: 'add', fattura: f });
}
function elimina(id) {
  S.fatture = S.fatture.filter((x) => x.id !== id); salva();
  invia({ action: 'delete', id });
}
function setAcc(mese, importo) {
  S.acc[mese] = Math.round(importo * 100) / 100; salva();
  invia({ action: 'setAccantonato', mese, importo: S.acc[mese] });
}

/* ---------- Avvisi derivati dai dati ---------- */
function avvisi() {
  const out = [];
  S.fatture.forEach((f) => {
    const c = calc(f);
    const nuova = f.fonte === 'gmail' && f.creato && Date.now() - new Date(f.creato).getTime() < 3 * 86400000;
    if (nuova) out.push({ tipo: 'blue', ic: 'mail', t: `Fattura ${f.numero || ''} archiviata`, s: `${f.descrizione || 'Provvigioni'} · bonifico atteso ${eur(c.bonifico)}`, id: f.id, peso: 1 });
    if (scaduta(f)) out.push({ tipo: 'copper', ic: 'clock', t: `Bonifico in ritardo · ${f.numero || 'senza numero'}`, s: `${eur(c.bonifico)} attesi · scaduta da ${giorniDa(f.data) - S.cfg.giorni} giorni`, id: f.id, peso: 0 });
    if (f.daVerificare) out.push({ tipo: 'copper', ic: 'alert', t: `Da controllare · ${f.numero || 'fattura'}`, s: 'Non ho letto tutti gli importi dal file Word', id: f.id, peso: 2 });
  });
  const m = isoOggi().slice(0, 7);
  const dovute = somma(delMese(m), 'tasse');
  const mancano = dovute - (S.acc[m] || 0);
  if (mancano > 0.5) out.push({ tipo: 'gold', ic: 'pct', t: `Metti da parte ${eur(mancano)}`, s: `Tasse di ${MESI[Number(m.slice(5)) - 1].toLowerCase()} non ancora accantonate`, vai: 'home', peso: 3 });
  return out.sort((a, b) => a.peso - b.peso);
}

/* ---------- Viste ---------- */
function vHome() {
  const lista = delMese(S.mese);
  const prev = delMese(meseShift(S.mese, -1));
  const lordo = somma(lista, 'lordo'), ena = somma(lista, 'ena'), netto = somma(lista, 'netto'), tasse = somma(lista, 'tasse');
  const lPrev = somma(prev, 'lordo');
  const varPct = lPrev > 0 && lordo > 0 ? Math.round(((lordo - lPrev) / lPrev) * 100) : null;
  const inc = lista.filter((f) => f.stato === 'incassata');
  const nonInc = lista.filter((f) => f.stato !== 'incassata');
  const incB = somma(inc, 'bonifico'), incL = somma(inc, 'lordo');
  const daB = somma(nonInc, 'bonifico'), daL = somma(nonInc, 'lordo');
  const acc = Math.min(S.acc[S.mese] || 0, tasse || Infinity);
  const manca = Math.max(0, tasse - acc);
  const todo = avvisi().filter((a) => a.vai !== 'home').slice(0, 3);
  const ultimoInc = S.fatture.filter((f) => f.dataIncasso).sort((a, b) => b.dataIncasso.localeCompare(a.dataIncasso))[0];

  return `<div class="page">
  <div class="top">
    <div class="stack">
      <span class="kicker">Provvigioni del mese</span>
      <div class="month">
        <button data-a="mese" data-d="-1" aria-label="Mese precedente">${svg('left', 18, 2.2)}</button>
        <span>${nomeMese(S.mese)}</span>
        <button data-a="mese" data-d="1" aria-label="Mese successivo">${svg('right', 18, 2.2)}</button>
      </div>
    </div>
    <button class="round" data-a="vai" data-v="avvisi" aria-label="Avvisi">${svg('bell')}${avvisi().length ? '<span class="dot"></span>' : ''}</button>
  </div>

  <div class="cream">
    <div class="row"><span class="lbl" style="letter-spacing:.08em;text-transform:uppercase">Fatturato lordo</span><span class="badge-out">Autoghinzani</span></div>
    <div class="stack" style="margin-top:-6px;gap:6px">
      <span class="big">${eur(lordo)}</span>
      <span style="font-size:12px;color:#2F5A44;font-weight:700">${lista.length} ${lista.length === 1 ? 'fattura' : 'fatture'}${varPct !== null ? ` · ${varPct >= 0 ? '+' : ''}${varPct}% sul mese prima` : ''}</span>
    </div>
    <hr>
    <div class="grid2">
      <div class="stack"><span class="lbl">Enasarco ${String(S.cfg.ena).replace('.', ',')}%</span><span class="v17">− ${eur(ena)}</span></div>
      <div class="stack"><span class="lbl">Netto</span><span class="v17" style="color:#1F5A3E">${eur(netto)}</span></div>
    </div>
  </div>

  <div class="card">
    <div class="row" style="align-items:flex-start">
      <div class="stack"><span style="font-size:13px;color:var(--muted);font-weight:600">Da mettere da parte per le tasse</span><span class="mid gold">${eur(tasse)}</span></div>
      <span class="pill s-fatturata">${S.cfg.tasse}% del netto</span>
    </div>
    <div class="bar"><i style="width:${tasse ? Math.round((acc / tasse) * 100) : 0}%;background:var(--gold)"></i></div>
    <div class="row">
      <button data-a="accImporto" style="border:0;background:transparent;padding:0;text-align:left;font-size:12px;color:var(--muted)">Accantonati ${eur(acc)} · mancano <b style="color:var(--text)">${eur(manca)}</b> ✎</button>
      <button class="btn gold sm" data-a="accTutto" ${tasse ? '' : 'disabled'}>${manca > 0 ? 'Accantonato' : 'Fatto ✓'}</button>
    </div>
  </div>

  <button class="card" data-a="vai" data-v="fatture" style="text-align:left;color:var(--text)">
    <div class="row" style="align-items:flex-start">
      <div class="stack"><span class="t12" style="font-weight:600">Arrivato sul conto</span><span class="v20 green">${eur(incB)}</span><span class="small">su ${eur(incL)} di imponibile</span></div>
      <div class="stack" style="align-items:flex-end"><span class="t12" style="font-weight:600">Deve ancora arrivare</span><span class="v20">${eur(daB)}</span><span class="small">su ${eur(daL)} di imponibile</span></div>
    </div>
    <div class="bar"><i style="flex:${incB || 0.0001};background:var(--green)"></i><i style="flex:${daB || (incB ? 0.0001 : 1)};background:#33463E"></i></div>
    <span class="t12">${ultimoInc ? `Ultimo bonifico ${dataBreve(ultimoInc.dataIncasso)}` : 'Nessun bonifico segnato'} · bonifico = imponibile + bollo − Enasarco</span>
  </button>

  <div class="stack" style="gap:8px">
    <span class="kicker">Da fare</span>
    ${todo.length ? todo.map(itemAvviso).join('') : `<div class="item"><span class="ico green">${svg('check', 18, 2.4)}</span><span class="grow"><b>Tutto in ordine</b><br><span class="t12">Nessuna fattura in ritardo o da controllare</span></span></div>`}
  </div>
  ${S.fatture.length ? '' : `<div class="empty">Ancora nessuna fattura.<br>Collega lo script Google in Avvisi › Impostazioni: prenderà da solo le fatture che mandi a Giulia.<button class="btn line-gold" data-a="demo">Prova con dati di esempio</button></div>`}
  ${S.sync ? `<div class="sync">${esc(S.sync)}</div>` : ''}
</div>`;
}

function itemAvviso(a) {
  const attr = a.id ? `data-a="apri" data-id="${esc(a.id)}"` : `data-a="vai" data-v="${a.vai || 'home'}"`;
  return `<button class="item" ${attr}><span class="ico ${a.tipo}">${svg(a.ic, 18, 2.2)}</span><span class="grow stack"><b class="ellipsis">${esc(a.t)}</b><span class="t12">${esc(a.s)}</span></span></button>`;
}

function filtrate() {
  const q = S.cerca.trim().toLowerCase();
  return ordinate(S.fatture).filter((f) => {
    if (S.filtro === 'verifica') { if (!f.daVerificare) return false; }
    else if (S.filtro !== 'tutte' && statoVis(f) !== S.filtro) return false;
    if (!q) return true;
    return [f.numero, f.descrizione, f.data, String(f.lordo)].join(' ').toLowerCase().includes(q);
  });
}
function righeFatture() {
  const lista = filtrate();
  if (!lista.length) return '<div class="empty">Nessuna fattura qui.</div>';
  return lista.map((f) => {
    const c = calc(f), sv = statoVis(f), step = STATI.indexOf(f.stato) + 1;
    const [cls, lbl] = f.daVerificare ? ['verifica', 'Da controllare'] : etichetta(f);
    return `<button class="inv" data-a="apri" data-id="${esc(f.id)}">
      <div class="row" style="align-items:flex-start">
        <div class="stack grow"><b class="ellipsis">${esc(f.descrizione || 'Provvigioni')}</b><span class="t12">N. ${esc(f.numero || '—')} · ${dataBreve(f.data)}</span></div>
        <div class="stack" style="align-items:flex-end;flex:none"><b>${eur(c.lordo)}</b><span class="t12">bonifico ${eur(c.bonifico)}</span></div>
      </div>
      <div class="row">
        <span class="pill s-${cls}">${lbl}</span>
        <span class="steps ${sv === 'scaduta' ? 'late' : ''}" aria-label="Avanzamento ${step} su 3"><i class="${step >= 1 ? 'on' : ''}"></i><i class="${step >= 2 ? 'on' : ''}"></i><i class="${step >= 3 ? 'on' : ''}"></i></span>
      </div>
    </button>`;
  }).join('');
}
function vFatture() {
  const conta = (fn) => S.fatture.filter(fn).length;
  const chips = [
    ['tutte', 'Tutte', conta(() => true)],
    ['inviata', 'Mandate a Giulia', conta((f) => statoVis(f) === 'inviata')],
    ['fatturata', 'Attesa bonifico', conta((f) => statoVis(f) === 'fatturata')],
    ['incassata', 'Incassate', conta((f) => f.stato === 'incassata')],
    ['scaduta', 'Scadute', conta(scaduta)],
    ['verifica', 'Da controllare', conta((f) => f.daVerificare)]
  ];
  return `<div class="page">
  <div class="top">
    <div class="stack"><h1>Fatture</h1><span class="sub">Provvigioni Autoghinzani</span></div>
    <button class="btn line-gold" data-a="vai" data-v="archivio">${svg('folder', 16)}Archivio</button>
  </div>
  <label class="search">${svg('search', 18)}<span class="sr">Cerca fatture</span><input id="cerca" type="search" placeholder="Cerca numero, mese, importo" value="${esc(S.cerca)}"></label>
  <div class="chips">${chips.map(([k, l, n]) => `<button class="chip ${S.filtro === k ? 'on' : ''}" data-a="filtro" data-f="${k}">${l} <span>${n}</span></button>`).join('')}</div>
  <div class="row t12" style="font-weight:600"><span>${filtrate().length} fatture</span><span>Imponibile · bonifico</span></div>
  <div id="lista" class="stack" style="gap:8px">${righeFatture()}</div>
</div>`;
}

function bloccoFile(f) {
  const links = [];
  if (f.pdfUrl) links.push(`<a class="item" href="${esc(f.pdfUrl)}" target="_blank" rel="noopener"><span class="ico gold">${svg('doc', 18)}</span><span class="grow stack"><b>Apri il PDF</b><span class="t12 ellipsis">${esc(f.pdfNome || 'Archivio su Google Drive')}</span></span></a>`);
  if (f.docxUrl) links.push(`<a class="item" href="${esc(f.docxUrl)}" target="_blank" rel="noopener"><span class="ico blue">${svg('doc', 18)}</span><span class="grow stack"><b>Apri il file Word</b><span class="t12">Quello mandato a Giulia</span></span></a>`);
  return links.join('');
}

function vDettaglio() {
  const f = S.fatture.find((x) => x.id === S.id);
  if (!f) { S.view = 'fatture'; return vFatture(); }
  const c = calc(f), step = STATI.indexOf(f.stato) + 1;
  const [cls, lbl] = f.daVerificare ? ['verifica', 'Da controllare'] : etichetta(f);
  const subs = [
    f.dataInvio ? `Il ${dataBreve(f.dataInvio)}` : 'Tocca quando la mandi',
    f.dataFattura ? `Il ${dataBreve(f.dataFattura)}` : 'Tocca quando Giulia la pubblica',
    f.dataIncasso ? `Arrivato il ${dataBreve(f.dataIncasso)}` : `Atteso ${eur(c.bonifico)} entro ${S.cfg.giorni} giorni`
  ];
  return `<div class="page" style="padding-bottom:110px">
  <div class="top">
    <button class="round" data-a="vai" data-v="fatture" aria-label="Torna alle fatture">${svg('left', 20, 2.2)}</button>
    <span style="font-size:15px;font-weight:700">Fattura N. ${esc(f.numero || '—')}</span>
    <button class="round" data-a="modifica" aria-label="Modifica">${svg('doc', 18)}</button>
  </div>
  <div class="stack" style="gap:6px">
    <span class="sub" style="font-size:13px">Autoghinzani · ${esc(f.descrizione || 'Provvigioni')}</span>
    <span class="big" style="font-size:40px">${eur(c.lordo)}</span>
    <span class="pill s-${cls}" style="align-self:flex-start">${lbl}</span>
  </div>
  <div class="card lines" style="padding:2px 16px">
    <div class="row"><span>Data fattura</span><b>${f.data ? dataBreve(f.data) + ' ' + f.data.slice(0, 4) : '—'}</b></div>
    <div class="row"><span>Imponibile</span><b>${eur(c.lordo)}</b></div>
    ${c.bollo ? `<div class="row"><span>Rivalsa bollo</span><b>${eur(c.bollo)}</b></div>` : ''}
    <div class="row"><span>Enasarco ${String(S.cfg.ena).replace('.', ',')}%</span><b>− ${eur(c.ena)}</b></div>
    <div class="row"><span>Bonifico atteso</span><b class="green">${eur(c.bonifico)}</b></div>
    <div class="row"><span>Da accantonare (${S.cfg.tasse}% di ${eur(c.netto)})</span><b class="gold">${eur(c.tasse)}</b></div>
  </div>
  <div class="card" style="gap:2px;padding:12px 16px">
    <span class="kicker" style="margin-bottom:2px">Stato · tocca per aggiornare</span>
    ${['Mandata a Giulia', 'Fatturata da Giulia', 'Bonifico arrivato'].map((l, i) => `<button class="step ${step > i ? 'on' : ''}" data-a="step" data-i="${i}" aria-pressed="${step > i}"><span class="c">${svg('check', 16, 3)}</span><span class="stack grow"><b>${l}</b><span class="t12">${esc(subs[i])}</span></span></button>`).join('')}
  </div>
  ${f.daVerificare ? `<button class="btn line-gold" data-a="verificata">${svg('check', 16, 2.4)}Ho controllato, i dati sono giusti</button>` : ''}
  ${bloccoFile(f)}
</div>
<div class="bottom-bar">
  <button class="btn ghost" data-a="elimina" aria-label="Elimina fattura" style="width:54px;height:54px;border-radius:27px;padding:0">${svg('x', 18, 2.4)}</button>
  <button class="btn block ${f.stato === 'incassata' ? 'ghost' : 'gold'}" data-a="incassa">${f.stato === 'incassata' ? 'Incassata · annulla' : 'Segna bonifico arrivato'}</button>
</div>`;
}

function vCarica() {
  const b = S.bozza || { numero: '', data: isoOggi(), descrizione: '', lordo: '', stato: 'inviata' };
  S.bozza = b;
  return `<div class="page" style="padding-bottom:110px">
  <div class="top">
    <button class="round" data-a="annulla" aria-label="Chiudi">${svg('x', 18, 2.4)}</button>
    <span style="font-family:var(--serif);font-size:20px;font-weight:600">${b.id ? 'Modifica fattura' : 'Nuova fattura'}</span>
    <span style="width:44px"></span>
  </div>
  ${b.id ? '' : `<a class="cream" href="${GENERATORE}" target="_blank" rel="noopener" style="padding:18px;gap:8px;color:var(--ink)">
    <span class="row"><b style="font-family:var(--serif);font-size:20px">Crea la fattura per Giulia</b>${svg('out', 20, 2.2)}</span>
    <span style="font-size:13px;color:var(--cream-muted);font-weight:600">Apre il tuo generatore. Quando premi "Invia a Giulia da Gmail", la fattura arriva qui da sola entro 10 minuti, con il file salvato nella cartella del mese.</span>
  </a>
  <span class="kicker" style="margin-top:6px">Oppure registrala a mano</span>`}
  <div class="card" style="gap:12px">
    <div class="grid2">
      <div class="field"><label for="f-numero">Numero</label><input id="f-numero" data-k="numero" value="${esc(b.numero)}" placeholder="5/2026"></div>
      <div class="field"><label for="f-data">Data</label><input id="f-data" type="date" data-k="data" value="${esc(b.data)}"></div>
    </div>
    <div class="field"><label for="f-lordo">Imponibile €</label><input id="f-lordo" inputmode="decimal" data-k="lordo" value="${esc(b.lordo)}" placeholder="808,00"></div>
    <div class="field"><label for="f-descr">Descrizione</label><input id="f-descr" data-k="descrizione" value="${esc(b.descrizione || '')}" placeholder="Provvigioni settembre 2026"></div>
    <div class="field"><label for="f-stato">Stato</label><select id="f-stato" data-k="stato">${STATI.map((s) => `<option value="${s}" ${b.stato === s ? 'selected' : ''}>${STATO_LABEL[s]}</option>`).join('')}</select></div>
  </div>
  <div class="cream" style="padding:14px 16px;border-radius:20px;display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:8px" id="calcoli">${calcoliBozza(calc(b))}</div>
</div>
<div class="bottom-bar"><button class="btn block gold" data-a="salvaBozza">${b.id ? 'Salva modifiche' : 'Registra fattura'}</button></div>`;
}
function calcoliBozza(c) {
  return `<span class="stack"><span class="lbl">Enasarco</span><b style="font-size:15px">${eur(c.ena)}</b></span>
  <span class="stack"><span class="lbl">Bonifico</span><b style="font-size:15px;color:#1F5A3E">${eur(c.bonifico)}</b></span>
  <span class="stack"><span class="lbl">Tasse ${S.cfg.tasse}%</span><b style="font-size:15px;color:#7A5A12">${eur(c.tasse)}</b></span>`;
}

function vTasse() {
  const y = S.anno;
  const mesi = Array.from({ length: 12 }, (_, i) => `${y}-${pad(i + 1)}`);
  const dati = mesi.map((m) => ({ m, dovute: somma(delMese(m), 'tasse'), acc: S.acc[m] || 0 }));
  const dovute = dati.reduce((s, d) => s + d.dovute, 0);
  const acc = dati.reduce((s, d) => s + Math.min(d.acc, d.dovute), 0);
  const max = Math.max(1, ...dati.map((d) => d.dovute));
  const anno = S.fatture.filter((f) => (f.data || '').startsWith(String(y)));
  return `<div class="page">
  <div class="top">
    <div class="month" style="margin-left:-8px">
      <button data-a="anno" data-d="-1" aria-label="Anno precedente">${svg('left', 18, 2.2)}</button>
      <h1 style="min-width:0">Tasse ${y}</h1>
      <button data-a="anno" data-d="1" aria-label="Anno successivo">${svg('right', 18, 2.2)}</button>
    </div>
    <span class="pill s-fatturata" style="padding:8px 12px">${S.cfg.tasse}% del netto</span>
  </div>
  <div class="cream" style="padding:18px 20px;gap:12px">
    <div class="row" style="align-items:flex-end">
      <span class="stack" style="gap:4px"><span class="lbl" style="letter-spacing:.08em;text-transform:uppercase">Nel salvadanaio</span><span class="big" style="font-size:34px">${eur(acc)}</span></span>
      <span style="font-size:12px;color:var(--cream-muted);text-align:right;font-weight:600">su ${eur(dovute)}<br><b style="color:#7A4A0C">mancano ${eur(Math.max(0, dovute - acc))}</b></span>
    </div>
    <div class="bars">${dati.map((d, i) => {
      const h = Math.round((d.dovute / max) * 84);
      const p = d.dovute ? Math.min(100, Math.round((d.acc / d.dovute) * 100)) : 0;
      return `<div><i style="height:${h}px;background:${p >= 100 ? '#1F5A3E' : `linear-gradient(to top,#1F5A3E ${p}%,#C2913A ${p}%)`}" title="${MESI[i]}: ${eur(d.acc)} su ${eur(d.dovute)}"></i><span>${MESI_INI[i]}</span></div>`;
    }).join('')}</div>
    <span style="display:flex;gap:14px;font-size:11px;color:var(--cream-muted);font-weight:600"><span style="display:flex;align-items:center;gap:5px"><i style="width:10px;height:10px;border-radius:3px;background:#1F5A3E;display:block"></i>Messo da parte</span><span style="display:flex;align-items:center;gap:5px"><i style="width:10px;height:10px;border-radius:3px;background:#C2913A;display:block"></i>Ancora da mettere</span></span>
  </div>
  <div class="grid2" style="gap:8px">
    <div class="card" style="padding:12px 14px;gap:2px"><span class="t12" style="font-weight:600">Imponibile anno</span><b style="font-size:17px">${eur(somma(anno, 'lordo'))}</b></div>
    <div class="card" style="padding:12px 14px;gap:2px"><span class="t12" style="font-weight:600">Enasarco trattenuto</span><b style="font-size:17px">${eur(somma(anno, 'ena'))}</b></div>
  </div>
  <span class="kicker">Scadenze principali</span>
  <div class="item" style="border-color:#3A3220"><span class="date"><b>30</b><span>NOV</span></span><span class="grow stack"><b>Secondo acconto</b><span class="t12">Importo esatto dal tuo commercialista</span></span></div>
  <div class="item"><span class="date" style="background:#1B2A24;color:#C9D3CD"><b>30</b><span>GIU</span></span><span class="grow stack"><b>Saldo ${y} + primo acconto ${y + 1}</b><span class="t12">Usa quanto hai accantonato qui</span></span></div>
  <button class="btn line-gold block" data-a="csv">${svg('down', 18, 2.2)}Scarica il riepilogo ${y} per il commercialista</button>
</div>`;
}

function vAvvisi() {
  const lista = avvisi();
  const c = S.cfg;
  return `<div class="page">
  <div class="top"><h1>Avvisi</h1><span class="sub">${new Date().toLocaleDateString('it-IT', { weekday: 'long', day: 'numeric', month: 'long' })}</span></div>
  <div class="stack" style="gap:6px">${lista.length ? lista.map(itemAvviso).join('') : '<div class="empty">Nessun avviso. Tutto in ordine.</div>'}</div>

  <span class="kicker" style="margin-top:8px">Impostazioni</span>
  <div class="card" style="gap:12px">
    <div class="grid2">
      <div class="field"><label for="c-ena">Enasarco %</label><input id="c-ena" inputmode="decimal" data-c="ena" value="${String(c.ena).replace('.', ',')}"></div>
      <div class="field"><label for="c-tasse">Tasse % del netto</label><input id="c-tasse" inputmode="decimal" data-c="tasse" value="${String(c.tasse).replace('.', ',')}"></div>
    </div>
    <div class="field"><label for="c-giorni">Giorni per il bonifico</label><input id="c-giorni" inputmode="numeric" data-c="giorni" value="${c.giorni}"></div>
  </div>
  <div class="card gold-line" style="gap:12px">
    <div class="row"><span class="stack"><b style="font-size:14px">Collegamento a Google</b><span class="t12">Fatture mandate a Giulia → Drive → notifiche</span></span><span style="width:8px;height:8px;border-radius:4px;background:${c.url ? 'var(--green)' : '#4A5E55'}"></span></div>
    <div class="field"><label for="c-url">Indirizzo dello script (URL)</label><input id="c-url" data-c="url" value="${esc(c.url)}" placeholder="https://script.google.com/macros/s/…/exec"></div>
    <div class="field"><label for="c-token">Codice segreto</label><input id="c-token" data-c="token" value="${esc(c.token)}" placeholder="dal registro dello script"></div>
    <button class="btn gold" data-a="sync">${svg('sync', 16, 2.2)}Sincronizza ora</button>
    ${S.sync ? `<span class="t12">${esc(S.sync)}</span>` : ''}
  </div>
  <span class="t12">Le notifiche sul telefono arrivano dall'app gratuita <b>ntfy</b>: iscriviti all'argomento che trovi nel registro dello script. Vedi la guida.</span>
</div>`;
}

function vArchivio() {
  const perAnno = {};
  S.fatture.forEach((f) => { const y = (f.data || '0000').slice(0, 4); const m = meseDi(f.data) || 'senza-data'; ((perAnno[y] = perAnno[y] || {})[m] = perAnno[y][m] || []).push(f); });
  const anni = Object.keys(perAnno).sort().reverse();
  const y = anni.includes(String(S.anno)) ? String(S.anno) : anni[0];
  const mesi = y ? Object.keys(perAnno[y]).sort().reverse() : [];
  if (S.aperto === null && mesi.length) S.aperto = mesi[0];
  return `<div class="page">
  <div class="top" style="justify-content:flex-start">
    <button class="round" data-a="vai" data-v="fatture" aria-label="Torna alle fatture">${svg('left', 20, 2.2)}</button>
    <div class="stack"><h1 style="font-size:26px">Archivio</h1><span class="sub">Su Google Drive, anno › mese</span></div>
  </div>
  <div class="item"><span class="ico gold">${svg('mail', 18)}</span><span class="grow stack"><b>${S.cfg.url ? 'Gmail collegato' : 'Gmail non ancora collegato'}</b><span class="t12">${S.cfg.url ? 'Prendo le fatture che mandi a Giulia e le archivio' : 'Imposta lo script in Avvisi › Impostazioni'}</span></span><span style="width:8px;height:8px;border-radius:4px;background:${S.cfg.url ? 'var(--green)' : '#4A5E55'}"></span></div>
  <div class="chips">${anni.map((a) => `<button class="chip ${a === y ? 'on' : ''}" data-a="annoArch" data-y="${a}">${a}</button>`).join('')}</div>
  <div class="stack" style="gap:6px">
  ${mesi.length ? mesi.map((m) => {
    const open = S.aperto === m;
    const files = ordinate(perAnno[y][m]);
    return `<div class="folder"><button data-a="cartella" data-m="${m}" aria-expanded="${open}">
      <span class="gold">${svg('folder', 18)}</span><b class="grow" style="font-size:14px">${m === 'senza-data' ? 'Senza data' : pad(m.slice(5)) + ' ' + MESI[Number(m.slice(5)) - 1]}</b>
      <span class="t12">${files.length} ${files.length === 1 ? 'fattura' : 'fatture'}</span><span class="t12" style="transform:rotate(${open ? 90 : 0}deg);display:flex">${svg('right', 16, 2.2)}</span></button>
      ${open ? files.map((f) => {
        const sv = statoVis(f);
        const nome = f.pdfNome || `Fattura_${(f.numero || '').replace(/\//g, '_')} · ${f.descrizione || 'Provvigioni'}`;
        const tag = f.pdfUrl ? 'a' : 'button';
        const attr = f.pdfUrl ? `href="${esc(f.pdfUrl)}" target="_blank" rel="noopener"` : `data-a="apri" data-id="${esc(f.id)}" style="border:0;border-top:1px solid var(--line-soft);background:transparent;width:calc(100% - 28px);text-align:left;padding:0"`;
        return `<${tag} class="file" ${attr}><span class="pdf">${f.pdfUrl ? 'PDF' : '—'}</span><span class="grow ellipsis" style="font-size:12px;font-weight:600">${esc(nome)}</span><span class="pill s-${sv}" style="font-size:11px;padding:3px 8px">${sv === 'incassata' ? 'Pagata' : sv === 'scaduta' ? 'Scaduta' : 'In attesa'}</span></${tag}>`;
      }).join('') + '<div style="height:6px"></div>' : ''}
    </div>`;
  }).join('') : '<div class="empty">L\'archivio si riempie da solo quando mandi una fattura a Giulia.</div>'}
  </div>
</div>`;
}

function nav() {
  const t = (v, ic, l) => `<button class="${S.view === v || (v === 'fatture' && ['dettaglio', 'archivio'].includes(S.view)) ? 'on' : ''}" data-a="vai" data-v="${v}">${svg(ic, 22)}${l}</button>`;
  return `<nav class="tabs" aria-label="Menu principale">${t('home', 'home', 'Home')}${t('fatture', 'doc', 'Fatture')}<button class="plus" data-a="nuova" aria-label="Nuova fattura"><span>${svg('plus', 24, 2.4)}</span></button>${t('tasse', 'pct', 'Tasse')}${t('avvisi', 'bell', 'Avvisi')}</nav>`;
}

const VISTE = { home: vHome, fatture: vFatture, dettaglio: vDettaglio, carica: vCarica, tasse: vTasse, avvisi: vAvvisi, archivio: vArchivio };
function render() {
  const app = document.getElementById('app');
  const conBarra = !['dettaglio', 'carica'].includes(S.view);
  app.innerHTML = VISTE[S.view]() + (conBarra ? nav() : '');
}

function toast(msg) {
  const el = document.createElement('div'); el.className = 'toast'; el.textContent = msg;
  document.body.appendChild(el); setTimeout(() => el.remove(), 3200);
}

/* ---------- Azioni ---------- */
const AZ = {
  vai: (d) => { S.view = d.v; S.aperto = null; window.scrollTo(0, 0); },
  mese: (d) => { S.mese = meseShift(S.mese, Number(d.d)); },
  anno: (d) => { S.anno += Number(d.d); },
  annoArch: (d) => { S.anno = Number(d.y); S.aperto = null; },
  cartella: (d) => { S.aperto = S.aperto === d.m ? '' : d.m; },
  filtro: (d) => { S.filtro = d.f; },
  apri: (d) => { S.id = d.id; S.view = 'dettaglio'; window.scrollTo(0, 0); },
  nuova: () => { S.bozza = null; S.view = 'carica'; window.scrollTo(0, 0); },
  annulla: () => { S.view = S.bozza && S.bozza.id ? 'dettaglio' : 'home'; S.bozza = null; },
  modifica: () => { const f = S.fatture.find((x) => x.id === S.id); S.bozza = Object.assign({}, f, { lordo: String(f.lordo).replace('.', ',') }); S.view = 'carica'; },
  step: (d) => {
    const f = S.fatture.find((x) => x.id === S.id); const i = Number(d.i);
    const cur = STATI.indexOf(f.stato) + 1;
    const nuovo = cur > i ? (i === 0 ? 'inviata' : STATI[i - 1]) : STATI[i];
    const campi = { stato: nuovo };
    if (nuovo === 'incassata' && !f.dataIncasso) campi.dataIncasso = isoOggi();
    if (nuovo !== 'incassata') campi.dataIncasso = '';
    if (nuovo === 'fatturata' && !f.dataFattura) campi.dataFattura = isoOggi();
    aggiorna(f.id, campi);
  },
  incassa: () => {
    const f = S.fatture.find((x) => x.id === S.id);
    if (f.stato === 'incassata') aggiorna(f.id, { stato: 'fatturata', dataIncasso: '' });
    else { aggiorna(f.id, { stato: 'incassata', dataIncasso: isoOggi() }); toast(`Metti da parte ${eur(calc(f).tasse)} per le tasse`); }
  },
  verificata: () => aggiorna(S.id, { daVerificare: false }),
  elimina: () => { if (confirm('Eliminare questa fattura dall\'app? I file su Drive restano.')) { elimina(S.id); S.view = 'fatture'; } },
  salvaBozza: () => {
    const b = S.bozza;
    if (!num(b.lordo)) { toast('Inserisci l\'imponibile'); return; }
    const f = { numero: (b.numero || '').trim(), data: b.data, descrizione: (b.descrizione || '').trim(), lordo: num(b.lordo), stato: b.stato, daVerificare: false };
    if (b.id) { aggiorna(b.id, f); S.view = 'dettaglio'; }
    else {
      f.fonte = 'manuale';
      if (f.stato === 'incassata') f.dataIncasso = isoOggi();
      aggiungi(f); S.view = 'fatture'; toast('Fattura registrata');
    }
    S.bozza = null;
  },
  accTutto: () => { const t = somma(delMese(S.mese), 'tasse'); setAcc(S.mese, t); toast('Segnato come accantonato'); },
  accImporto: () => {
    const v = prompt('Quanto hai già messo da parte per ' + nomeMese(S.mese) + '?', String(S.acc[S.mese] || 0).replace('.', ','));
    if (v !== null) setAcc(S.mese, num(v));
  },
  sync: () => sincronizza(),
  csv: () => {
    const righe = [['Numero', 'Data', 'Descrizione', 'Imponibile', 'Bollo', 'Enasarco', 'Bonifico', 'Netto', 'Tasse', 'Stato', 'Data incasso']];
    ordinate(S.fatture.filter((f) => (f.data || '').startsWith(String(S.anno)))).reverse().forEach((f) => {
      const c = calc(f);
      righe.push([f.numero, f.data, f.descrizione, c.lordo, c.bollo, c.ena, c.bonifico, c.netto, c.tasse, STATO_LABEL[f.stato], f.dataIncasso || ''].map((v) => typeof v === 'number' ? v.toFixed(2).replace('.', ',') : v));
    });
    const csv = righe.map((r) => r.map((v) => `"${String(v ?? '').replace(/"/g, '""')}"`).join(';')).join('\n');
    const a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob(['﻿' + csv], { type: 'text/csv;charset=utf-8' }));
    a.download = `Provvigioni_${S.anno}_Autoghinzani.csv`; a.click();
  },
  demo: () => {
    const m0 = isoOggi().slice(0, 7);
    const ultimo = (m) => { const [y, mm] = m.split('-').map(Number); return `${m}-${pad(new Date(y, mm, 0).getDate())}`; };
    const es = [[meseShift(m0, -1), 808, 'fatturata'], [meseShift(m0, -2), 1240, 'incassata'], [meseShift(m0, -3), 960, 'incassata'], [meseShift(m0, -4), 1105, 'incassata']];
    S.fatture = es.map(([m, lordo, stato], i) => {
      const nome = MESI[Number(m.slice(5)) - 1].toLowerCase();
      return { id: 'demo' + i, numero: `${5 - i}/${m.slice(0, 4)}`, data: ultimo(m), descrizione: `Provvigioni ${nome} ${m.slice(0, 4)}`, lordo, bollo: 2, stato, fonte: 'gmail', dataInvio: ultimo(m), dataIncasso: stato === 'incassata' ? ultimo(meseShift(m, 1)).slice(0, 8) + '10' : '', creato: i === 0 ? new Date().toISOString() : ultimo(m) + 'T09:00:00Z' };
    });
    S.acc = {};
    es.slice(1).forEach(([m]) => { S.acc[m] = somma(delMese(m), 'tasse'); });
    S.mese = meseShift(m0, -1);
    salva(); toast('Dati di esempio caricati');
  }
};

document.addEventListener('click', (e) => {
  const el = e.target.closest('[data-a]');
  if (!el || el.disabled) return;
  const fn = AZ[el.dataset.a]; if (!fn) return;
  e.preventDefault();
  fn(el.dataset);
  render();
});

document.addEventListener('input', (e) => {
  const t = e.target;
  if (t.id === 'cerca') { S.cerca = t.value; const l = document.getElementById('lista'); if (l) l.innerHTML = righeFatture(); return; }
  if (t.dataset.k && S.bozza) {
    S.bozza[t.dataset.k] = t.value;
    const box = document.getElementById('calcoli'); if (box) box.innerHTML = calcoliBozza(calc(S.bozza));
  }
  if (t.dataset.c) {
    const k = t.dataset.c;
    S.cfg[k] = ['url', 'token'].includes(k) ? t.value.trim() : num(t.value);
    salva();
  }
});

document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'visible') sincronizza(true); });

// Netlify aggiunge il riquadro "Powered by Netlify" in basso a destra: alzo la barra perché resti cliccabile.
const segnaBadge = () => document.body.classList.toggle('con-badge', !!document.getElementById('nl-badge-frame'));
new MutationObserver(segnaBadge).observe(document.body, { childList: true });
segnaBadge();

render();
sincronizza(true);
